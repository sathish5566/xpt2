<!-- sidebar -->
    <div class="large-4 columns">
        <aside class="secBg sidebar">
            <div class="row">
                <!-- most view Widget -->
                <div class="large-12 medium-7 medium-centered columns">
                    <div class="widgetBox">
                        <div class="widgetTitle">
                            <h5>Most View Videos</h5>
                        </div>
                        <div class="widgetContent">                                    
                            <div class="video-box thumb-border">
                                <div class="video-img-thumb">
                                    <img src="http://placehold.it/300x190" alt="most viewed videos">
                                    <a href="#" class="hover-posts">
                                        <span><i class="fa fa-play"></i>Watch Video</span>
                                    </a>
                                </div>
                                <div class="video-box-content">
                                    <h6><a href="#">There are many variations of passage. </a></h6>
                                    <p>
                                        <span><i class="fa fa-user"></i><a href="#">admin</a></span>
                                        <span><i class="fa fa-clock-o"></i>5 January 16</span>
                                        <span><i class="fa fa-eye"></i>1,862K</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- end most view Widget -->
            </div>
        </aside>
    </div><!-- end sidebar -->